const container = document.querySelector(".container");
const form = document.querySelector("form");
const input = document.querySelector("input");
const harflar = [
  "A",
  "B",
  "C",
  "D",
  "F",
  "E",
  "G",
  "H",
  "J",
  "K",
  "L",
  "M",
  "N",
  "O",
  "P",
  "Q",
  "R",
  "S",
  "T",
  "U",
  "V",
  "X",
  "W",
  "Y",
  "Z",
];

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const gap = input.value;
  const arr = gap.toLocaleUpperCase().split("");
  container.innerHTML = "";
  const sorted = arr.filter((val) => {
    return harflar.includes(val);
  });

  sorted.forEach((val) => {
    let html = `<img src="./sudoImages/${val}.jpg" alt="" />`;
    container.insertAdjacentHTML("beforeend", html);
  });
});
